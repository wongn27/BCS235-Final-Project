//  Declare SQL Query for SQLite
var createStatement = "CREATE TABLE IF NOT EXISTS Users (id INTEGER PRIMARY KEY AUTOINCREMENT, first_name TEXT, last_name TEXT, username TEXT, email Text, address TEXT, address2 TEXT, city TEXT, state TEXT, postal_code INTEGER, phone_number TEXT, mobile_number TEXT, password TEXT)";
var selectAllStatement = "SELECT * FROM Users";
var insertStatement = "INSERT INTO Users (first_name, last_name, username, email, address, address2, city, state, postal_code, phone_number, mobile_number, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
var updateStatement = "UPDATE Users SET first_name = ?, last_name = ? , username = ? , email = ? , address = ?, address2 = ?, city = ?, state = ?, postal_code = ?, phone_number = ?, mobile_number = ?, password = ? WHERE id=?";
var deleteStatement = "DELETE FROM Users WHERE id=?";
var dropStatement = "DROP TABLE Users";
var db = openDatabase("DB", "1.0", "Users Database", 200000); // Open SQLite Database
var dataset;
var DataType;

function initDatabase() // Function Call When Page is ready.
{
    try {
        if (!window.openDatabase) // Check browser is supported SQLite or not.
        {
            alert('Databases are not supported in this browser.');
        } else {
            createTable(); // If supported then call Function for create table in SQLite
        }
    } catch (e) {
        if (e == 2) {
            // Version number mismatch. 
            console.log("Invalid database version.");
        } else {
            console.log("Unknown error " + e + ".");
        }
        return;
    }
}

function createTable() // Function for Create Table in SQLite.
{
    db.transaction(function(tx) {
        tx.executeSql(createStatement, [], success, onError);
    });
}


function success() 
{
	console.log("SQLite success");
}

function insertRecord() // Get value from Input and insert record . Function Call when Save/Submit Button Click..
{
    var firstNameTemp = $('input:text[id=firstName]').val();
    var lastNameTemp = $('input:text[id=lastName]').val();
    var usernameTemp = $('input:text[id=lastName]').val();
    var emailTemp = $('input:text[id=email]').val();
    var addressTemp = $('input:text[id=address]').val();
    var address2Temp = $('input:text[id=address2]').val();
    var cityTemp = $('input:text[id=city]').val();
    var stateTemp = $('input:text[id=state]').val();
    var postalCodeTemp = $('input:text[id=postalCode]').val();
    var phoneNumberTemp = $('input:text[id=phoneNumber]').val();
    var mobileNumberTemp = $('input:text[id=mobileNumber]').val();
    var passwordTemp = $('#password').val();

    db.transaction(function(tx) {
        tx.executeSql(insertStatement, [firstNameTemp, lastNameTemp, usernameTemp, emailTemp, addressTemp, address2Temp,
            cityTemp, stateTemp, postalCodeTemp, phoneNumberTemp, mobileNumberTemp, passwordTemp], insertCallBack, onError);
    });
}

function deleteRecord(id) // Get id of record . Function Call when Delete Button Click..
{
    db.transaction(function(tx) {
        tx.executeSql(deleteStatement, [id], showRecords, onError);
        alert("Delete Successfully");
    });
    resetForm();
}

function updateRecord() // Get id of record . Function Call when Delete Button Click..
{
    var firstNameUpdate = $('#firstName').val();
    var lastNameUpdate = $('#lastName').val();
    var usernameUpdate = $('#username').val();
    var emailUpdate = $('#email').val();
    var addressUpdate = $('#address').val();
    var address2Update = $('#address2').val();
    var cityUpdate = $('#city').val();
    var stateUpdate = $('#state').val();
    var postalCodeUpdate = $('#postalCode').val();
    var phoneNumberUpdate = $('#phoneNumber').val();
    var mobileNumberUpdate = $('#mobileNumber').val();
    var passwordUpdate = $('#password').val();
    var useridupdate = $("#id").val();

    console.log("updateRecord");

	console.log("firstNameUpdate: "+ firstNameUpdate );
	console.log("lastNameUpdate: "+ lastNameUpdate );
	console.log("usernameUpdate: "+ usernameUpdate );
	console.log("emailUpdate: "+ emailUpdate );
	console.log("addressUpdate: "+ addressUpdate );
	console.log("address2Update: "+ address2Update );
	console.log("cityUpdate: "+ cityUpdate );
	console.log("stateUpdate: "+ stateUpdate );
	console.log("postalCodeUpdate: "+ postalCodeUpdate );
	console.log("phoneNumberUpdate: "+ phoneNumberUpdate );
	console.log("mobileNumberUpdate: "+ mobileNumberUpdate );
	console.log("passwordUpdate: "+ passwordUpdate );
	console.log("useridupdate: "+ useridupdate );

    db.transaction(function(tx) {
        tx.executeSql(updateStatement, [firstNameUpdate, lastNameUpdate, usernameUpdate, emailUpdate, addressUpdate, address2Update,
            cityUpdate, stateUpdate, postalCodeUpdate, phoneNumberUpdate, mobileNumberUpdate, passwordUpdate, Number(useridupdate)], updateSuccess, onError);
    });
    


}

function updateSuccess() {

console.log("updateSuccess");

    $(".alert").hide();
    $(".alert-success").show({
        effect: "pulsate",
        duration: 500
    });
    $(".alert-success > span").html("Record Updated Successfuly!!");
    window.location.href = "viewDataSQLite.html";

}


function dropTable() // Function Call when Drop Button Click.. Talbe will be dropped from database.
{
    db.transaction(function(tx) {
        tx.executeSql(dropStatement, [], success, onError);
    });
    initDatabase();
}

function editRecord(id) {
    console.log(id);

    // Check browser support
    if (typeof(Storage) !== "undefined") {
        // Store
        localStorage.setItem("editID", id);
    } else {
        alert = "Sorry, your browser does not support Web Storage...";
    }

    // Retrieve
    editID = localStorage.getItem("editID");
    console.log("editRecord: " + id);
    window.location.href = "editDataSQLite.html";
}

// Transaction error callback
function errorCB(err) {
    console.log("Error processing SQL: " + err.code);
}

function loadRecord(id) // Function for display records which are retrived from database.
{
    console.log(id);
    var sqlStatement = "select * from users where id=" + id;
    console.log(sqlStatement);

    db.transaction(function(tx) {
        tx.executeSql(sqlStatement, [], function(tx, result) {
            dataset = result.rows;

            if (dataset.length > 0) {
                item = dataset.item(0);
                $("#firstName").val((item['first_name']).toString());
                $("#lastName").val((item['last_name']).toString());
                $("#username").val((item['username']).toString());
                $("#email").val((item['email']).toString());
                $("#address").val((item['address']).toString());
                $("#address2").val((item['address2']).toString());
                $("#city").val((item['city']).toString());
                $("#state").val((item['state']).toString());
                $("#postalCode").val((item['postal_code']).toString());
                $("#phoneNumber").val((item['phone_number']).toString());
                $("#mobileNumber").val((item['mobile_number']).toString());
                $("#password").val((item['password']).toString());
                $("#id").val((item['id']).toString())

                console.log(dataset);
                console.log(item);

                $(".alert").hide();
                $(".alert-success").show({
                    effect: "pulsate",
                    duration: 500
                });
                $(".alert-success > span").html("Record Loaded Successfuly!!");
            }
        });
    });
}

function resetForm() // Function for reset form input values.
{

    $("#firstName").val("");

    $("#lastName").val("");

    $("#username").val("");

    $("#email").val("");

    $("#address").val("");

    $("#address2").val("");

    $("#city").val("");

    $("#state").val("");

    $("#postalCode").val("");

    $("#phoneNumber").val("");

    $("#mobileNumber").val("");

    $("#password").val("");

    $("#id").val("");

}

function insertCallBack() //Function for Load and Reset...
{
    resetForm();
    $(".alert").hide();
    $(".alert-success").show({
        effect: "pulsate",
        duration: 500
    });
    $(".alert-success > span").html("Record Inserted Successfuly!!");

    window.location.href = "viewDataSQLite.html";
}


function loadAndReset() //Function for Load and Reset...
{

    resetForm();

}

function onError(tx, error) // Function for Hendeling Error...
{
    alert(error.message);
}



$(document).ready(function() // Call function when page is ready for load..
    {
        initDatabase();
    });


function showRecords() // Function For Retrive data from Database Display records as list
{

    $("#results").html('')

    db.transaction(function(tx) {

        tx.executeSql(selectAllStatement, [], function(tx, result) {

            dataset = result.rows;


            if (dataset.length > 0) {

                /*Table start tag*/
                var table = '<table id="usersTable" class="display" cellspacing="0" width="100%">';
                /*Table head start tag*/
                table += '<thead>';
                table += '<tr>';
                table += '<th>' + 'First Name' + '</th>';
                table += '<th>' + 'Last Name' + '</th>';
             
                table += '<th>' + 'Email' + '</th>';
              
                table += '<th>' + 'Phone Number' + '</th>';
              
                table += '<th>' + 'Edit' + '</th>';
                table += '<th>' + 'Delete' + '</th>';
                table += '</tr>';
                table += '</thead>'; /*Table head end tag*/

                /*Table body start tag*/
                table += '<tbody>';
                for (var i = 0, item = null; i < dataset.length; i++) {

                    item = dataset.item(i);

                    table += '<tr>';
                    table += '<td>' + item['first_name'] + '</td>';
                    table += '<td>' + item['last_name'] + '</td>';
                    table += '<td>' + item['email'] + '</td>';
                    
                    table += '<td>' + item['phone_number'] + '</td>';

                    table += "<td><a href='#' onclick='editRecord(" + item['id'] + ");'><img border='0' alt='edit user' src='edit_user.png' width='25' height='25'></a></td>";
                    table += "<td><a href='#' onclick='deleteRecord(" + item['id'] + ");'><img border='0' alt='remove user' src='remove_user.png' width='25' height='25'></a></td>";
                    table += '</tr>';

                }
                /*Table body end tag*/
                table += '</tbody>';
                /*Table foot start tag*/
                table += '<tfoot>';
                table += '<tr>';
                table += '<th>' + 'First Name' + '</th>';
                table += '<th>' + 'Last Name' + '</th>';
             
                table += '<th>' + 'Email' + '</th>';
              
                table += '<th>' + 'Phone Number' + '</th>';

                table += '<th>' + 'Edit' + '</th>';
                table += '<th>' + 'Delete' + '</th>';
                table += '</tr>';
                table += '</tfoot>';
                /*Table foot end tag*/
                table += '</table>'; /*Table closing tag*/
                $("#results").append(table);
            }


            $('#usersTable').DataTable();

        });

    });

}

function login(email, password){
	var SQL ="Select * from users where email ='" + email +"' and password='"+ password +"'";
	console.log(SQL);
	  db.transaction(function(tx) {

        tx.executeSql(SQL, [], function(tx, result) {

            rows = result.rows;
			console.log(rows);

            if (rows.length > 0) {
					console.log("Successful Login");
				    window.location.href = "viewDataSQLite.html";
			}
			else{
				console.log("Invalid Login");
			}
	
		})
	})
	
	//console.log(email);
	//console.log(password);


}